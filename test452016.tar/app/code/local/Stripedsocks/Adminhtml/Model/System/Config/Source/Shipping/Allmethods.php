<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magento.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magento.com for more information.
 *
 * @category    Mage
 * @package     Mage_Adminhtml
 * @copyright  Copyright (c) 2006-2015 X.commerce, Inc. (http://www.magento.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class Stripedsocks_Adminhtml_Model_System_Config_Source_Shipping_Allmethods extends Mage_Adminhtml_Model_System_Config_Source_Shipping_Allmethods
{
    /**
     * Return array of carriers.
     * If $isActiveOnlyFlag is set to true, will return only active carriers
     *
     * @param bool $isActiveOnlyFlag
     * @return array
     */
    public function toOptionArray($isActiveOnlyFlag=false)
    {
		/* edited by PS*/
		$resource = Mage::getSingleton('core/resource');
		$readConnection = $resource->getConnection('core_read');
		$query = 'SELECT DISTINCT (delivery_type) FROM ' . $resource->getTableName('shipping_matrixrate');
		$results = $readConnection->fetchAll($query);
		/*foreach($results as $row)
		{	echo "<pre>";
			print_r($row['delivery_type']);			
		}*/			 
		
		$methods = array(array('value'=>'', 'label'=>''));
        $carriers = Mage::getSingleton('shipping/config')->getAllCarriers();
        foreach ($carriers as $carrierCode=>$carrierModel) {
            if (!$carrierModel->isActive() && (bool)$isActiveOnlyFlag === true) {
                continue;
            }
            $carrierMethods = $carrierModel->getAllowedMethods();
            if (!$carrierMethods) {
                continue;
            }
            $carrierTitle = Mage::getStoreConfig('carriers/'.$carrierCode.'/title');
            $methods[$carrierCode] = array(
                'label'   => $carrierTitle,
                'value' => array(),
            );			
            foreach ($carrierMethods as $methodCode=>$methodTitle) {
				//echo "<pre>";
				//print_r($methodCode);
				if($carrierCode=="matrixrate")
				{
		foreach($results as $row)
		{	
			//echo "<pre>";
			//print_r($row['delivery_type']);
			$lower_string = strtolower($row['delivery_type']);			
			$result_string = preg_replace("/[\s]/", "_", $lower_string);
			//print_r($result_string);
			$methods[$carrierCode]['value'][] = array(
                    'value' => $carrierCode.'_'.$methodCode.'_'.$result_string,
                    'label' => '['.$carrierCode.'] '.$methodTitle.' '.$row['delivery_type'],
                );			
		}				}
				else
				{
					$methods[$carrierCode]['value'][] = array(
                    'value' => $carrierCode.'_'.$methodCode,
                    'label' => '['.$carrierCode.'] '.$methodTitle,
                );
				}
				
            }
        }

        return $methods;
    }
}
